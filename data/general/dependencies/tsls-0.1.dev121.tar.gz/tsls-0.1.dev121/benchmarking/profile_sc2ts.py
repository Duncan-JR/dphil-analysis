"""
Run tsls Viterbi on sc2ts queries, for profiling and comparing builds.

The queries are those of bench.py's sc2ts workloads (a spread of the
110 scaling queries), matched against an sc2ts ARG with the sc2ts model
(num_mismatches = 3, weight_by_n=False) and optionally the k-mismatch
threshold. Prints, for each query, the time, a hash of the path, the
path's model log likelihood and the HMM's statistics, as JSON.

    uv run python profile_sc2ts.py data/subargs/sc2ts_bench_n100000.trees --k 1
"""

import hashlib
import json
import pathlib
import time

import click
import numpy as np

import bench
import matcher
import queries


@click.command()
@click.argument("ts_path")
@click.option("--k", "mismatch_threshold", type=int, default=None)
@click.option("--queries", "query_ids", default=None)
@click.option("--sparse/--no-sparse", default=True)
@click.option("--repeats", type=int, default=1)
@click.option("--index-min-sites", type=int, default=None)
def main(ts_path, mismatch_threshold, query_ids, sparse, repeats, index_min_sites):
    path = pathlib.Path(ts_path)
    workload = bench.sc2ts_workload(
        "sc2ts",
        str(path.relative_to("data")),
        10,
        mismatch_threshold=mismatch_threshold,
    )
    ts, H, _, ids, model = bench.load_workload(pathlib.Path("data"), workload)
    if query_ids is not None:
        ids = [int(q) for q in query_ids.split(",")]
    m = bench.make_matcher(ts, model, mismatch_threshold=mismatch_threshold)
    num_alleles = matcher.site_num_alleles(ts, model["alleles"])
    mu = np.full(ts.num_sites, model["mu"])
    for qid in ids:
        h = H[qid].astype(np.int8)
        start, end = queries.query_window(H, qid)
        for _ in range(repeats):
            kwargs = {}
            if index_min_sites is not None:
                kwargs["index_min_sites"] = index_min_sites
            hmm = m.make_hmm(sparse=sparse, **kwargs)
            matched = np.zeros(ts.num_sites, dtype=np.int8)
            before = time.perf_counter()
            left, right, parent = hmm.find_path(h, start, end, matched)
            seconds = time.perf_counter() - before
            digest = hashlib.md5()
            for array in [left, right, parent, matched]:
                digest.update(np.ascontiguousarray(array).tobytes())
            log_likelihood = matcher.model_path_log_likelihood(
                h,
                matched,
                left[::-1],
                ts.sites_position,
                start,
                end,
                rho=m.recombination,
                mu=mu,
                n=ts.num_nodes,
                num_alleles=num_alleles,
            )
            row = {
                "query": qid,
                "time": round(seconds, 4),
                "segments": len(left),
                "path": digest.hexdigest()[:12],
                "log_likelihood": log_likelihood,
                "sparse_sites": hmm.num_sparse_sites,
                "mean_values": round(hmm.mean_num_values, 1),
                "updated": round(hmm.mean_num_updated, 1),
                "delta": round(getattr(hmm, "mean_delta_size", float("nan")), 2),
                "memory_mib": round(hmm.total_memory / 2**20, 1),
            }
            print(json.dumps(row), flush=True)


if __name__ == "__main__":
    main()
